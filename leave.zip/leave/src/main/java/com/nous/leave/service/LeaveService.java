package com.nous.leave.service;

import java.util.List;

import com.nous.leave.models.Leave;

public interface LeaveService {

	public List<Leave> findAll();

	public Leave findById(int id);

	public void apply(Leave leave);

	public void deleteById(int id);

	public void approve(Leave leave, int id);
}
