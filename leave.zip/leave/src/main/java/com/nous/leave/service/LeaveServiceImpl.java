package com.nous.leave.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nous.leave.dao.LeaveManageRepository;
import com.nous.leave.models.Leave;
import com.nous.leave.utilities.RecordNotFoundException;

@Service
public class LeaveServiceImpl implements LeaveService {

	@Autowired
	LeaveManageRepository leaveManageRepository;

	@Override
	public List<Leave> findAll() {

		List<Leave> leaveObj = leaveManageRepository.findAll();
		return leaveObj;
	}

	@Override
	public Leave findById(int id) {

		Optional<Leave> leave = leaveManageRepository.findById(id);
		if (!leave.isPresent()) {
			throw new RecordNotFoundException("Leave with id" + id + "is not present");
		}
		return leave.get();
	}

	@Override
	public void apply(Leave leave) {
		leaveManageRepository.save(leave);
	}

	@Override
	@Transactional
	public void deleteById(int id) {
		leaveManageRepository.deleteById(id);
	}

	@Override
	@Transactional
	public void approve(Leave leave, int id) {
		Optional<Leave> leaveObj = leaveManageRepository.findById(id);
		if (!leaveObj.isPresent()) {
			throw new RecordNotFoundException("Leave with id" + id + "is not present");
		}
		leave.setId(id);
		leaveManageRepository.save(leave);

	}
}
