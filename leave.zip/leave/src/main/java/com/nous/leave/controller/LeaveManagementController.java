package com.nous.leave.controller;

import java.util.List;
import java.util.Locale;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nous.leave.models.Leave;
import com.nous.leave.service.LeaveService;

@Controller
@RequestMapping("/api/v/1")
public class LeaveManagementController {

	private static final Logger logger = LoggerFactory.getLogger(LeaveManagementController.class);
	@Autowired
	private LeaveService leaveService;

	@Autowired
	private MessageSource messageSource;

	@GetMapping
	public List<Leave> getAllLeaves() {
		logger.info("Retrieve all the leaves Data");
		return leaveService.findAll();
	}

	@GetMapping("/leave/{id}")
	public Leave retrieveLeave(
			@PathVariable @Validated @Min(value = 0, message = "id must be greater than 0") @Max(value = 1000, message = "id must be lower than or equal to 1000") int id) {
		logger.info("Retrieve Leave data by id");
		Leave leave = leaveService.findById(id);
		return leave;
	}

	@PostMapping("/leave")
	public String applyLeave(@Valid @RequestBody Leave leave, Locale locale) {
		logger.info("Applying leave");
		leaveService.apply(leave);
		return messageSource.getMessage("sucess.insert", null, locale);
	}

	@PutMapping("/leave/{id}")
	public String appoveLeave(@Valid @RequestBody Leave leave, @PathVariable int id, Locale locale) {
		logger.info("Approving Leaves");
		leaveService.approve(leave, id);
		if (leave.isAcceptRejectFlag()) {
			return messageSource.getMessage("sucess.approve", null, locale);
		} else
			return messageSource.getMessage("sucess.reject", null, locale);
	}

	@DeleteMapping("/leave/{id}")
	public String deleteLeave(@PathVariable int id, Locale locale) {
		logger.info("Deleting leaves data");
		leaveService.deleteById(id);
		return messageSource.getMessage("error.delete", null, locale);
	}
}
