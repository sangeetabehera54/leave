package com.nous.leave.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nous.leave.models.Leave;

public interface LeaveManageRepository extends JpaRepository<Leave, Integer> {
	

}
